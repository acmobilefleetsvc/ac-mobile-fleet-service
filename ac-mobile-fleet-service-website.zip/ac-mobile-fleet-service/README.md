# AC Mobile Fleet Service Website

This is a production-ready Next.js website package for AC Mobile Fleet Service LLC.

## What is included

- Next.js website
- Tailwind CSS styling
- Mobile responsive layout
- Click-to-call phone buttons
- Contact/request service form using mailto
- SEO metadata
- No external icon package required

## Local preview

Install Node.js first, then run:

```bash
npm install
npm run dev
```

Open:

```text
http://localhost:3000
```

## Deploy with Vercel

1. Create a GitHub account.
2. Create a new repository named `ac-mobile-fleet-service`.
3. Upload all files from this folder into the repository.
4. Create a Vercel account.
5. Click Add New Project.
6. Import your GitHub repository.
7. Click Deploy.

## Connect GoDaddy domain to Vercel

In Vercel:

1. Open your project.
2. Go to Settings.
3. Go to Domains.
4. Add your domain, such as `acmobilefleetsvc.com`.

Then in GoDaddy DNS, use the records Vercel provides. Common Vercel records are:

A Record:

```text
Host: @
Value: 76.76.21.21
```

CNAME Record:

```text
Host: www
Value: cname.vercel-dns.com
```

DNS can take a few minutes to a few hours to update.

## Contact form note

The included form uses `mailto:` so it opens the visitor's email app. For a more professional form that sends directly to your inbox, connect Formspree, Basin, Jotform, or a custom API route later.

## Edit contact info

Open `app/page.js` and edit these lines near the top:

```js
const phone = '(937) 516-6739';
const email = 'Maintenance@ACMobileFleetSVC.Com';
const website = 'www.acmobilefleetsvc.com';
```
